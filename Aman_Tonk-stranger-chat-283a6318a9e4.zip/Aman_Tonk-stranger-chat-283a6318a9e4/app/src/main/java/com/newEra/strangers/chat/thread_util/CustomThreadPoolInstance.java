package com.newEra.strangers.chat.thread_util;

public class CustomThreadPoolInstance {
    public static CustomThreadPoolExecutor threadPoolExecutor = new CustomThreadPoolExecutor(10);
}
