package com.newEra.strangers.chat.util;

import androidx.recyclerview.widget.RecyclerView;
import com.newEra.strangers.chat.adapter.ConversationAdapter;
import com.newEra.strangers.chat.adapter.FriendMessageAdapter;

public class BackgroundTaskUtil {
    public static void updateConversationAdapter(ConversationAdapter adapter) {
    }

    public static void updateFriendMsgAdapter(FriendMessageAdapter adapter, RecyclerView recyclerView) {
    }
}
