package com.newEra.strangers.chat.util;

public class IntentExtrasKeys {
    public static final String USER_ID = "userId";
    public static final String RESET_ACCOUNT = "reser_account";

}
