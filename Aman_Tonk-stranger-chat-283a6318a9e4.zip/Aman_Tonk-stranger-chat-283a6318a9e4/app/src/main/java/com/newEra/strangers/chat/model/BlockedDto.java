package com.newEra.strangers.chat.model;

public class BlockedDto {
    private String body1;
    private String body2;
    private String heading;

    public String getHeading() {
        return this.heading;
    }

    public void setHeading(String heading2) {
        this.heading = heading2;
    }

    public String getBody1() {
        return this.body1;
    }

    public void setBody1(String body12) {
        this.body1 = body12;
    }

    public String getBody2() {
        return this.body2;
    }

    public void setBody2(String body22) {
        this.body2 = body22;
    }
}