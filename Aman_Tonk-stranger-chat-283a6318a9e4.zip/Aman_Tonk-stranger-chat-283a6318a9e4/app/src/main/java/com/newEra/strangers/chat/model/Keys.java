package com.newEra.strangers.chat.model;

public class Keys {
    public static final String HEIGHT = "height";
    public static final String IMAGE_ID = "image_id";
    public static final String IMAGE_URL = "image_url";
    public static final String IS_LOCAL = "is_local";
    public static final String ORIGINAL = "original";
    public static final String ROOM_ID = "room_id";
    public static final String THUMBNAIL = "thumbnail";
    public static final String URL = "url";
    public static final String USER_ID = "user_id";
    public static final String WIDTH = "width";
}
