package com.newEra.strangers.chat.comparators;

public enum SortOrder {
    ASCENDING,
    DESCENDING
}
