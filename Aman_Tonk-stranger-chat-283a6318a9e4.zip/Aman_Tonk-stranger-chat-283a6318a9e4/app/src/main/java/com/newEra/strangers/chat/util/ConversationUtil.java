package com.newEra.strangers.chat.util;

import java.util.List;
import com.newEra.strangers.chat.model.StConversation;

public class ConversationUtil {
    public static List<StConversation> getSortedStConversation(List<StConversation> list) {
        return null;
    }
}
