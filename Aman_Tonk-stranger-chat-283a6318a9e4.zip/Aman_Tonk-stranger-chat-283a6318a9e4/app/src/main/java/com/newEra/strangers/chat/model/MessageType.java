package com.newEra.strangers.chat.model;

public class MessageType {
    public static final int IMAGE_RECEIVED = 3;
    public static final int IMAGE_SENT = 4;
    public static final int RECEIVED = 1;
    public static final int SENT = 0;
}
